now

1 html files are geting formated with "html"
and
php files are formated with "blade-formater"

both does not give any instant reply on errors but in html formater we can find it with

:ConformInfo

in blade-formater we cant.

so we might need html-ls to work with it.

we can formate inside .php file wht html with <leader> c f

<!--
Y: WARNING:
   with this we will get " name.img" space in double cote problem.
-->

but you can get html errors wihh
:ConformInfo
after <leader>cf and solve the html error and then

<!-- G: save the file which format with "blade-formater" -->

we alos need java formater ni next time

<!--IMP: RUST -->

we lnstalled some rust Mason: and rust preaty much worked automatically.

--this is the one that work every time we see it in
  
- latest: if i only install toolchain with rustup everyting works automatically dont need to add anyting rust-analyzer is the best in this.

    ◍ rustywind (keywords: angular, html, jsx, javascript, typescript, vue)

-- this seem unusefull evern if INSTALLED.
◍ codelldb (keywords: c, c++, rust, zig)
◍ rust-analyzer rust_analyzer (keywords: rust)
◍ rust_hdl vhdl_ls (keywords: vhdl)
◍tarlark-rust starlark_rust (keywords: starlark)

javascript in html i not working and jquery is not working.

added various perfomance improvement thing in webdev.lua && performance.lua

most of them can be turned of in case.

 <!--WARNING: most imp thing is when file is larger than 1mb the treesitter will stop giving COLORS -->
<!-- IMP:  NO COLORS in any file  -->

so either stop it from performance.lua or close the biger file and reopen oter smaller files.
